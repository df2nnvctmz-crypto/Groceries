package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Receipt
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.MainViewModel
import com.example.ui.bills.BillsScreen
import com.example.ui.home.HomeScreen
import com.example.ui.search.SearchScreen
import com.example.ui.swaps.SwapsScreen
import com.example.ui.theme.AppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                MainApp()
            }
        }
    }
}

sealed class Screen(val route: String, val label: String, val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector, val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Home : Screen("home", "Today", Icons.Filled.Home, Icons.Outlined.Home)
    object Search : Screen("search", "Search", Icons.Filled.Search, Icons.Outlined.Search)
    object Swaps : Screen("swaps", "Swaps", Icons.Filled.SwapHoriz, Icons.Outlined.SwapHoriz)
    object Bills : Screen("bills", "Bills", Icons.Filled.Receipt, Icons.Outlined.Receipt)
}

val items = listOf(
    Screen.Home,
    Screen.Search,
    Screen.Swaps,
    Screen.Bills
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp() {
    val navController = rememberNavController()
    val viewModel: MainViewModel = viewModel()
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        bottomBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                NavigationBar(
                    modifier = Modifier.clip(androidx.compose.foundation.shape.RoundedCornerShape(32.dp)),
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentDestination = navBackStackEntry?.destination
                    items.forEach { screen ->
                        NavigationBarItem(
                            icon = {
                                Icon(
                                    if (currentDestination?.hierarchy?.any { it.route == screen.route } == true)
                                        screen.selectedIcon else screen.unselectedIcon,
                                    contentDescription = screen.label
                                )
                            },
                            label = { Text(screen.label) },
                            selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = com.example.ui.theme.GreenPrimary.copy(alpha = 0.1f),
                                selectedIconColor = com.example.ui.theme.GreenPrimary,
                                selectedTextColor = com.example.ui.theme.GreenPrimary
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    spotlightFood = uiState.allFoods.find { it.name.contains("Berliner") } ?: uiState.allFoods.firstOrNull(),
                    recommendedFoods = uiState.allFoods.filter { it.healthScore >= 80 }.take(5)
                )
            }
            composable(Screen.Search.route) {
                SearchScreen(
                    searchQuery = uiState.searchQuery,
                    onSearchQueryChange = { viewModel.search(it) },
                    searchResults = uiState.displayedFoods
                )
            }
            composable(Screen.Swaps.route) {
                SwapsScreen(
                    badFoods = uiState.allFoods.filter { it.nutriGrade == "D" || it.nutriGrade == "E" },
                    getSwapsFor = { viewModel.getSwapsFor(it) }
                )
            }
            composable(Screen.Bills.route) {
                BillsScreen()
            }
        }
    }
}
