package com.example.data

import android.content.Context
import com.example.R
import com.example.domain.NutriScoreCalculator
import java.io.BufferedReader
import java.io.InputStreamReader

class FoodRepository(private val context: Context) {

    private val _foods = mutableListOf<FoodItem>()

    fun loadFoods(): List<FoodItem> {
        if (_foods.isNotEmpty()) return _foods

        try {
            val inputStream = context.resources.openRawResource(R.raw.food_database)
            val reader = BufferedReader(InputStreamReader(inputStream))
            reader.readLine() // skip header

            var line: String? = reader.readLine()
            while (line != null) {
                val tokens = line.split(",")
                if (tokens.size >= 10) {
                    val item = FoodItem(
                        name = tokens[0],
                        category = tokens[1],
                        kcal = tokens[2].toDoubleOrNull() ?: 0.0,
                        proteinG = tokens[3].toDoubleOrNull() ?: 0.0,
                        carbsG = tokens[4].toDoubleOrNull() ?: 0.0,
                        sugarsG = tokens[5].toDoubleOrNull() ?: 0.0,
                        fatG = tokens[6].toDoubleOrNull() ?: 0.0,
                        saturatedFatG = tokens[7].toDoubleOrNull() ?: 0.0,
                        fiberG = tokens[8].toDoubleOrNull() ?: 0.0,
                        saltG = (tokens[9].toDoubleOrNull() ?: 0.0) * 2.5 / 1000.0, // convert sodium mg to salt g
                    )
                    
                    val (grade, score) = NutriScoreCalculator.calculate(item)
                    item.nutriGrade = grade
                    item.healthScore = score
                    
                    _foods.add(item)
                }
                line = reader.readLine()
            }
            reader.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return _foods
    }

    fun getAllFoods(): List<FoodItem> = loadFoods()

    fun searchFoods(query: String): List<FoodItem> {
        val all = loadFoods()
        if (query.isBlank()) return all
        return all.filter { it.name.contains(query, ignoreCase = true) }
    }
    
    fun getRecommendedSwaps(food: FoodItem): List<FoodItem> {
        val all = loadFoods()
        return all.filter { 
            it.category.equals(food.category, ignoreCase = true) && 
            it.healthScore >= food.healthScore + 5 &&
            it.healthScore > 65 &&
            it.name != food.name
        }.sortedByDescending { it.healthScore }
    }
}
