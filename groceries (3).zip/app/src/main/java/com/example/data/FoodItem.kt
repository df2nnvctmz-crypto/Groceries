package com.example.data

data class FoodItem(
    val name: String,
    val category: String,
    val kcal: Double,
    val proteinG: Double,
    val carbsG: Double,
    val sugarsG: Double,
    val fatG: Double,
    val saturatedFatG: Double,
    val fiberG: Double,
    val saltG: Double,
    val isBeverage: Boolean = category.equals("Beverages", ignoreCase = true),
    var nutriGrade: String = "A",
    var healthScore: Int = 100
)
