package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.data.FoodItem
import com.example.data.FoodRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = FoodRepository(application)

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        val foods = repository.getAllFoods()
        _uiState.update { it.copy(allFoods = foods, displayedFoods = foods) }
    }

    fun search(query: String) {
        val results = repository.searchFoods(query)
        _uiState.update { it.copy(searchQuery = query, displayedFoods = results) }
    }

    fun selectFood(food: FoodItem?) {
        _uiState.update { it.copy(selectedFood = food) }
    }
    
    fun getSwapsFor(food: FoodItem): List<FoodItem> {
        return repository.getRecommendedSwaps(food)
    }
}

data class UiState(
    val allFoods: List<FoodItem> = emptyList(),
    val displayedFoods: List<FoodItem> = emptyList(),
    val searchQuery: String = "",
    val selectedFood: FoodItem? = null
)
